import { useState, useEffect } from 'react';
import { Plus, Trash2, Printer } from 'lucide-react';
import api from '../services/api';
// Optional: Use a toast library if added, or simple js alert

const Billing = () => {
  const [customers, setCustomers] = useState([]);
  const [selectedCustomer, setSelectedCustomer] = useState('');
  
  const [medicines, setMedicines] = useState([{ name: '', quantity: 1, price: 0 }]);
  const [totalAmount, setTotalAmount] = useState(0);
  
  const [status, setStatus] = useState('Paid');
  const [expectedPaymentDate, setExpectedPaymentDate] = useState('');

  const [loading, setLoading] = useState(false);

  useEffect(() => {
    // Fetch all customers for the dropdown
    const fetchCustomers = async () => {
      try {
        const { data } = await api.get('/customers?limit=1000'); // Assuming we want all or paginated search
        setCustomers(data.customers);
      } catch (error) {
        console.error('Failed to load customers', error);
      }
    };
    fetchCustomers();
  }, []);

  // Recalculate total whenever medicines change
  useEffect(() => {
    const total = medicines.reduce((acc, curr) => acc + (Number(curr.quantity) * Number(curr.price)), 0);
    setTotalAmount(total);
  }, [medicines]);

  const handleAddMedicine = () => {
    setMedicines([...medicines, { name: '', quantity: 1, price: 0 }]);
  };

  const handleRemoveMedicine = (index) => {
    const newMedicines = medicines.filter((_, i) => i !== index);
    setMedicines(newMedicines);
  };

  const handleMedicineChange = (index, field, value) => {
    const newMedicines = [...medicines];
    newMedicines[index][field] = value;
    setMedicines(newMedicines);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!selectedCustomer) return alert('Please select a customer');
    if (medicines.some(m => !m.name)) return alert('Medicine names cannot be empty');
    
    setLoading(true);
    try {
      const payload = {
        customer: selectedCustomer,
        medicines,
        status,
        expectedPaymentDate: status === 'Unpaid' ? expectedPaymentDate : null
      };
      
      const { data } = await api.post('/bills', payload);
      alert('Bill created successfully!');
      
      // Reset form
      setSelectedCustomer('');
      setMedicines([{ name: '', quantity: 1, price: 0 }]);
      setStatus('Paid');
      setExpectedPaymentDate('');
    } catch (error) {
      console.error('Failed to create bill', error);
      alert('Error creating bill');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      <div className="flex justify-between items-center bg-white dark:bg-card p-6 rounded-lg shadow-sm border border-border">
        <h1 className="text-2xl font-semibold text-gray-900 dark:text-gray-100">Generate New Bill</h1>
        {/* Future Print Feature */}
        <button className="flex items-center text-primary hover:text-primary/80">
          <Printer className="w-5 h-5 mr-2" /> Print Preset
        </button>
      </div>

      <form onSubmit={handleSubmit} className="bg-white dark:bg-card shadow rounded-lg border border-border overflow-hidden p-6 space-y-6">
        {/* Customer Selection */}
        <div>
          <label className="block text-sm font-medium text-muted-foreground mb-1">Select Customer</label>
          <select 
            required
            className="w-full border rounded p-2 bg-transparent text-foreground"
            value={selectedCustomer}
            onChange={(e) => setSelectedCustomer(e.target.value)}
          >
            <option value="">-- Choose a customer --</option>
            {customers.map(c => (
              <option key={c._id} value={c._id}>{c.name} ({c.fatherName}) - {c.city}</option>
            ))}
          </select>
        </div>

        {/* Medicines List */}
        <div>
          <div className="flex justify-between items-center mb-2">
            <label className="block text-sm font-medium text-muted-foreground">Medicines</label>
            <button 
              type="button" 
              onClick={handleAddMedicine}
              className="text-sm flex items-center text-primary bg-primary/10 px-2 py-1 rounded"
            >
              <Plus className="w-4 h-4 mr-1" /> Add Item
            </button>
          </div>
          
          <div className="space-y-3">
            {medicines.map((med, index) => (
              <div key={index} className="flex gap-4 items-end bg-gray-50 dark:bg-muted/50 p-4 rounded border border-border">
                <div className="flex-1">
                  <label className="block text-xs text-muted-foreground mb-1">Medicine Name</label>
                  <input 
                    required type="text" placeholder="Disprin"
                    className="w-full border rounded p-2 bg-white dark:bg-card text-sm"
                    value={med.name} onChange={(e) => handleMedicineChange(index, 'name', e.target.value)}
                  />
                </div>
                <div className="w-24">
                  <label className="block text-xs text-muted-foreground mb-1">Quantity</label>
                  <input 
                    required type="number" min="1"
                    className="w-full border rounded p-2 bg-white dark:bg-card text-sm"
                    value={med.quantity} onChange={(e) => handleMedicineChange(index, 'quantity', e.target.value)}
                  />
                </div>
                <div className="w-32">
                  <label className="block text-xs text-muted-foreground mb-1">Price (₹)</label>
                  <input 
                    required type="number" min="0" step="0.01"
                    className="w-full border rounded p-2 bg-white dark:bg-card text-sm"
                    value={med.price} onChange={(e) => handleMedicineChange(index, 'price', e.target.value)}
                  />
                </div>
                <div className="w-24 bg-gray-200 dark:bg-gray-800 p-2 rounded text-center text-sm font-semibold flex items-center justify-center h-[38px]">
                  ₹{(med.quantity * med.price).toFixed(2)}
                </div>
                <button 
                  type="button" onClick={() => handleRemoveMedicine(index)}
                  disabled={medicines.length === 1}
                  className="text-destructive hover:bg-destructive/10 p-2 rounded disabled:opacity-50 h-[38px]"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        </div>

        <div className="border-t border-border pt-4 grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-muted-foreground mb-1">Payment Status</label>
              <div className="flex gap-4">
                <label className="flex items-center">
                  <input type="radio" name="status" value="Paid" checked={status === 'Paid'} onChange={() => setStatus('Paid')} className="mr-2 text-primary focus:ring-primary" />
                  Paid
                </label>
                <label className="flex items-center">
                  <input type="radio" name="status" value="Unpaid" checked={status === 'Unpaid'} onChange={() => setStatus('Unpaid')} className="mr-2 text-primary focus:ring-primary" />
                  Unpaid
                </label>
              </div>
            </div>

            {status === 'Unpaid' && (
              <div>
                <label className="block text-sm font-medium text-muted-foreground mb-1">Expected Payment Date</label>
                <input 
                  required type="date"
                  className="w-full border rounded p-2 bg-transparent text-foreground"
                  value={expectedPaymentDate} onChange={(e) => setExpectedPaymentDate(e.target.value)}
                />
              </div>
            )}
          </div>

          <div className="bg-primary/5 rounded border border-primary/20 p-6 flex flex-col justify-center items-end">
            <span className="text-sm text-muted-foreground uppercase tracking-wider">Total Amount</span>
            <span className="text-4xl font-bold text-primary">₹{totalAmount.toFixed(2)}</span>
            
            <button 
              type="submit" disabled={loading}
              className="mt-6 w-full py-3 px-4 border border-transparent rounded-md shadow-sm text-white bg-primary hover:bg-primary/90 focus:outline-none font-medium disabled:opacity-50"
            >
              {loading ? 'Processing...' : 'Save & Generate Bill'}
            </button>
          </div>
        </div>
      </form>
    </div>
  );
};

export default Billing;
